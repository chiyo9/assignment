class StaticPagesController < ApplicationController
  def home
  end
  
  def category
  end
  
  def locations
  end
  
  def media
  end
end
