require 'test_helper'

class StaticPagesControllerTest < ActionDispatch::IntegrationTest
  test "should get ..." do
    get static_pages_..._url
    assert_response :success
  end

end
